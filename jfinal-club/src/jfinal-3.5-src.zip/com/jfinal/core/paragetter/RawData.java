package com.jfinal.core.paragetter;

public class RawData {
	private final String data;

	public RawData(String data) {
		this.data = data;
	}

	public final String getData() {
		return data;
	}
}
